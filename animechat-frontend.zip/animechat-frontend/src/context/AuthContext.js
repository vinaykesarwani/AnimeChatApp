import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Try to restore session from localStorage
    const savedCreds = localStorage.getItem('animechat_creds');
    if (savedCreds) {
      const { username, password } = JSON.parse(savedCreds);
      api.defaults.auth = { username, password };
      api.get('/api/users/self')
        .then(res => setUser(res.data))
        .catch(() => {
          localStorage.removeItem('animechat_creds');
          api.defaults.auth = null;
        })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (username, password) => {
    api.defaults.auth = { username, password };
    try {
      const res = await api.get('/api/users/self');
      setUser(res.data);
      localStorage.setItem('animechat_creds', JSON.stringify({ username, password }));
      return { success: true };
    } catch (err) {
      api.defaults.auth = null;
      return { success: false, error: err.response?.status === 401 ? 'Invalid username or password' : 'Login failed' };
    }
  };

  const logout = () => {
    setUser(null);
    api.defaults.auth = null;
    localStorage.removeItem('animechat_creds');
  };

  const register = async (username, password) => {
    try {
      await api.post('/api/users', { username, password });
      return await login(username, password);
    } catch (err) {
      return { success: false, error: err.response?.data || 'Registration failed' };
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

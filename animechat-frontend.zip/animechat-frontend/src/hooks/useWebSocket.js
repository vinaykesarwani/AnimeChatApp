import { useEffect, useRef, useState, useCallback } from 'react';
import SockJS from 'sockjs-client';
import { Client } from '@stomp/stompjs';

const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

export function useWebSocket(roomId, credentials, onMessage) {
  const clientRef = useRef(null);
  const [status, setStatus] = useState('disconnected'); // 'connecting' | 'connected' | 'disconnected'

  useEffect(() => {
    if (!roomId || !credentials) return;

    setStatus('connecting');

    const client = new Client({
      webSocketFactory: () => new SockJS(`${BASE_URL}/ws`),
      connectHeaders: {
        login: credentials.username,
        passcode: credentials.password,
      },
      reconnectDelay: 3000,
      onConnect: () => {
        setStatus('connected');
        client.subscribe(`/topic/chat/${roomId}`, (frame) => {
          try {
            const event = JSON.parse(frame.body);
            onMessage(event);
          } catch (e) {
            console.error('WS parse error', e);
          }
        });
      },
      onDisconnect: () => setStatus('disconnected'),
      onStompError: () => setStatus('disconnected'),
    });

    client.activate();
    clientRef.current = client;

    return () => {
      client.deactivate();
      clientRef.current = null;
    };
  }, [roomId, credentials?.username]);

  const sendMessage = useCallback((content, replyToMessageId = null) => {
    if (!clientRef.current?.connected) return false;
    const payload = { content, replyToMessageId };
    clientRef.current.publish({
      destination: `/app/chat.send/${roomId}`,
      body: JSON.stringify(payload),
    });
    return true;
  }, [roomId]);

  const editMessage = useCallback((messageId, content) => {
    if (!clientRef.current?.connected) return;
    clientRef.current.publish({
      destination: '/app/chat.edit',
      body: JSON.stringify({ messageId, content }),
    });
  }, []);

  const deleteMessage = useCallback((messageId) => {
    if (!clientRef.current?.connected) return;
    clientRef.current.publish({
      destination: '/app/chat.delete',
      body: JSON.stringify({ messageId }),
    });
  }, []);

  return { status, sendMessage, editMessage, deleteMessage };
}

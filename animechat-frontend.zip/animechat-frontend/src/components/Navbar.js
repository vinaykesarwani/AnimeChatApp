import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const initials = user?.username?.slice(0, 2).toUpperCase() || '??';

  return (
    <nav className="navbar">
      <Link to="/" className="navbar-logo">
        <div className="logo-dot" />
        ANIME<span>CHAT</span>
      </Link>

      <div className="navbar-actions">
        {user ? (
          <>
            <div className="nav-user">
              <div className="nav-avatar">{initials}</div>
              <span>{user.username}</span>
              {user.role === 'ADMIN' && (
                <span className="tag tag-default">ADMIN</span>
              )}
            </div>
            <button className="btn btn-secondary btn-sm" onClick={handleLogout}>
              Sign Out
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="btn btn-ghost btn-sm">Sign In</Link>
            <Link to="/register" className="btn btn-primary btn-sm">Join Now</Link>
          </>
        )}
      </div>
    </nav>
  );
}
